﻿namespace QLTOUR.GiaoDIen
{
    partial class DatTour
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DatTour));
            this.lbType = new System.Windows.Forms.Label();
            this.lbDescription = new System.Windows.Forms.Label();
            this.lbPrice = new System.Windows.Forms.Label();
            this.lbIDTour = new System.Windows.Forms.Label();
            this.ptb_anhtour = new System.Windows.Forms.PictureBox();
            this.txt_timtour = new System.Windows.Forms.TextBox();
            this.lb_tenloaitour = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.richboxDescription = new System.Windows.Forms.RichTextBox();
            this.lb_tgketthuc = new System.Windows.Forms.Label();
            this.lb_thoigian = new System.Windows.Forms.Label();
            this.lb_tgbatdau = new System.Windows.Forms.Label();
            this.lb_valueslve = new System.Windows.Forms.Label();
            this.lb_slve = new System.Windows.Forms.Label();
            this.lb_phuongtien = new System.Windows.Forms.Label();
            this.lb_xp = new System.Windows.Forms.Label();
            this.lb_valuexp = new System.Windows.Forms.Label();
            this.lb_valuephuongtien = new System.Windows.Forms.Label();
            this.lb_matour = new System.Windows.Forms.Label();
            this.btn_datve = new System.Windows.Forms.Button();
            this.lb_giatour = new System.Windows.Forms.Label();
            this.lb_tentour = new System.Windows.Forms.Label();
            this.btn_tim = new System.Windows.Forms.Button();
            this.lb_tennv = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBoxTransport = new System.Windows.Forms.ComboBox();
            this.comboBoxBudget = new System.Windows.Forms.ComboBox();
            this.btn_all = new System.Windows.Forms.Button();
            this.comboBoxTourType = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dgv_thongtintour = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.ptb_anhtour)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_thongtintour)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbType
            // 
            this.lbType.AutoSize = true;
            this.lbType.Font = new System.Drawing.Font("Bahnschrift SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbType.ForeColor = System.Drawing.Color.Black;
            this.lbType.Location = new System.Drawing.Point(382, 369);
            this.lbType.Name = "lbType";
            this.lbType.Size = new System.Drawing.Size(74, 19);
            this.lbType.TabIndex = 19;
            this.lbType.Text = "Loại tour";
            this.lbType.Visible = false;
            // 
            // lbDescription
            // 
            this.lbDescription.AutoSize = true;
            this.lbDescription.Font = new System.Drawing.Font("Bahnschrift SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDescription.ForeColor = System.Drawing.Color.Black;
            this.lbDescription.Location = new System.Drawing.Point(382, 408);
            this.lbDescription.Name = "lbDescription";
            this.lbDescription.Size = new System.Drawing.Size(48, 19);
            this.lbDescription.TabIndex = 18;
            this.lbDescription.Text = "Mô tả";
            this.lbDescription.Visible = false;
            // 
            // lbPrice
            // 
            this.lbPrice.AutoSize = true;
            this.lbPrice.Font = new System.Drawing.Font("Bahnschrift SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPrice.ForeColor = System.Drawing.Color.Black;
            this.lbPrice.Location = new System.Drawing.Point(18, 587);
            this.lbPrice.Name = "lbPrice";
            this.lbPrice.Size = new System.Drawing.Size(51, 19);
            this.lbPrice.TabIndex = 17;
            this.lbPrice.Text = "Price:";
            this.lbPrice.Visible = false;
            // 
            // lbIDTour
            // 
            this.lbIDTour.AutoSize = true;
            this.lbIDTour.Font = new System.Drawing.Font("Bahnschrift SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbIDTour.ForeColor = System.Drawing.Color.Black;
            this.lbIDTour.Location = new System.Drawing.Point(18, 548);
            this.lbIDTour.Name = "lbIDTour";
            this.lbIDTour.Size = new System.Drawing.Size(64, 19);
            this.lbIDTour.TabIndex = 16;
            this.lbIDTour.Text = "Tour ID:";
            this.lbIDTour.Visible = false;
            // 
            // ptb_anhtour
            // 
            this.ptb_anhtour.Location = new System.Drawing.Point(22, 73);
            this.ptb_anhtour.Name = "ptb_anhtour";
            this.ptb_anhtour.Size = new System.Drawing.Size(606, 259);
            this.ptb_anhtour.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ptb_anhtour.TabIndex = 15;
            this.ptb_anhtour.TabStop = false;
            this.ptb_anhtour.Visible = false;
            // 
            // txt_timtour
            // 
            this.txt_timtour.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_timtour.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.txt_timtour.Location = new System.Drawing.Point(17, 77);
            this.txt_timtour.Name = "txt_timtour";
            this.txt_timtour.Size = new System.Drawing.Size(142, 25);
            this.txt_timtour.TabIndex = 5;
            // 
            // lb_tenloaitour
            // 
            this.lb_tenloaitour.AutoSize = true;
            this.lb_tenloaitour.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lb_tenloaitour.Location = new System.Drawing.Point(492, 369);
            this.lb_tenloaitour.Name = "lb_tenloaitour";
            this.lb_tenloaitour.Size = new System.Drawing.Size(96, 20);
            this.lb_tenloaitour.TabIndex = 14;
            this.lb_tenloaitour.Text = "Tên loại tour";
            this.lb_tenloaitour.Visible = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.richboxDescription);
            this.groupBox4.Controls.Add(this.lbType);
            this.groupBox4.Controls.Add(this.lbDescription);
            this.groupBox4.Controls.Add(this.lbPrice);
            this.groupBox4.Controls.Add(this.lbIDTour);
            this.groupBox4.Controls.Add(this.ptb_anhtour);
            this.groupBox4.Controls.Add(this.lb_tenloaitour);
            this.groupBox4.Controls.Add(this.lb_tgketthuc);
            this.groupBox4.Controls.Add(this.lb_thoigian);
            this.groupBox4.Controls.Add(this.lb_tgbatdau);
            this.groupBox4.Controls.Add(this.lb_valueslve);
            this.groupBox4.Controls.Add(this.lb_slve);
            this.groupBox4.Controls.Add(this.lb_phuongtien);
            this.groupBox4.Controls.Add(this.lb_xp);
            this.groupBox4.Controls.Add(this.lb_valuexp);
            this.groupBox4.Controls.Add(this.lb_valuephuongtien);
            this.groupBox4.Controls.Add(this.lb_matour);
            this.groupBox4.Controls.Add(this.btn_datve);
            this.groupBox4.Controls.Add(this.lb_giatour);
            this.groupBox4.Controls.Add(this.lb_tentour);
            this.groupBox4.Location = new System.Drawing.Point(823, 12);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(649, 702);
            this.groupBox4.TabIndex = 9;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Thông tin chi tiết TOUR";
            // 
            // richboxDescription
            // 
            this.richboxDescription.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richboxDescription.BulletIndent = 2;
            this.richboxDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.richboxDescription.ForeColor = System.Drawing.Color.Black;
            this.richboxDescription.Location = new System.Drawing.Point(386, 445);
            this.richboxDescription.Name = "richboxDescription";
            this.richboxDescription.ReadOnly = true;
            this.richboxDescription.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.richboxDescription.Size = new System.Drawing.Size(242, 161);
            this.richboxDescription.TabIndex = 21;
            this.richboxDescription.Text = "";
            this.richboxDescription.Visible = false;
            // 
            // lb_tgketthuc
            // 
            this.lb_tgketthuc.AutoSize = true;
            this.lb_tgketthuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lb_tgketthuc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lb_tgketthuc.Location = new System.Drawing.Point(166, 516);
            this.lb_tgketthuc.Name = "lb_tgketthuc";
            this.lb_tgketthuc.Size = new System.Drawing.Size(68, 20);
            this.lb_tgketthuc.TabIndex = 13;
            this.lb_tgketthuc.Text = "Kết thúc";
            this.lb_tgketthuc.Visible = false;
            // 
            // lb_thoigian
            // 
            this.lb_thoigian.AutoSize = true;
            this.lb_thoigian.Font = new System.Drawing.Font("Bahnschrift SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_thoigian.ForeColor = System.Drawing.Color.Black;
            this.lb_thoigian.Location = new System.Drawing.Point(18, 484);
            this.lb_thoigian.Name = "lb_thoigian";
            this.lb_thoigian.Size = new System.Drawing.Size(74, 19);
            this.lb_thoigian.TabIndex = 12;
            this.lb_thoigian.Text = "Thời gian";
            this.lb_thoigian.Visible = false;
            // 
            // lb_tgbatdau
            // 
            this.lb_tgbatdau.AutoSize = true;
            this.lb_tgbatdau.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lb_tgbatdau.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lb_tgbatdau.Location = new System.Drawing.Point(167, 484);
            this.lb_tgbatdau.Name = "lb_tgbatdau";
            this.lb_tgbatdau.Size = new System.Drawing.Size(79, 20);
            this.lb_tgbatdau.TabIndex = 11;
            this.lb_tgbatdau.Text = "Xuất phát";
            this.lb_tgbatdau.Visible = false;
            // 
            // lb_valueslve
            // 
            this.lb_valueslve.AutoSize = true;
            this.lb_valueslve.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_valueslve.Location = new System.Drawing.Point(166, 446);
            this.lb_valueslve.Name = "lb_valueslve";
            this.lb_valueslve.Size = new System.Drawing.Size(53, 20);
            this.lb_valueslve.TabIndex = 10;
            this.lb_valueslve.Text = "SL vé ";
            this.lb_valueslve.Visible = false;
            // 
            // lb_slve
            // 
            this.lb_slve.AutoSize = true;
            this.lb_slve.Font = new System.Drawing.Font("Bahnschrift SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_slve.ForeColor = System.Drawing.Color.Black;
            this.lb_slve.Location = new System.Drawing.Point(18, 445);
            this.lb_slve.Name = "lb_slve";
            this.lb_slve.Size = new System.Drawing.Size(95, 19);
            this.lb_slve.TabIndex = 9;
            this.lb_slve.Text = "Số lượng vé";
            this.lb_slve.Visible = false;
            // 
            // lb_phuongtien
            // 
            this.lb_phuongtien.AutoSize = true;
            this.lb_phuongtien.Font = new System.Drawing.Font("Bahnschrift SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_phuongtien.ForeColor = System.Drawing.Color.Black;
            this.lb_phuongtien.Location = new System.Drawing.Point(18, 408);
            this.lb_phuongtien.Name = "lb_phuongtien";
            this.lb_phuongtien.Size = new System.Drawing.Size(96, 19);
            this.lb_phuongtien.TabIndex = 8;
            this.lb_phuongtien.Text = "Phương tiện";
            this.lb_phuongtien.Visible = false;
            // 
            // lb_xp
            // 
            this.lb_xp.AutoSize = true;
            this.lb_xp.Font = new System.Drawing.Font("Bahnschrift SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_xp.ForeColor = System.Drawing.Color.Black;
            this.lb_xp.Location = new System.Drawing.Point(18, 369);
            this.lb_xp.Name = "lb_xp";
            this.lb_xp.Size = new System.Drawing.Size(118, 19);
            this.lb_xp.TabIndex = 7;
            this.lb_xp.Text = "Điểm xuất phát";
            this.lb_xp.Visible = false;
            // 
            // lb_valuexp
            // 
            this.lb_valuexp.AutoSize = true;
            this.lb_valuexp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_valuexp.Location = new System.Drawing.Point(166, 370);
            this.lb_valuexp.Name = "lb_valuexp";
            this.lb_valuexp.Size = new System.Drawing.Size(79, 20);
            this.lb_valuexp.TabIndex = 6;
            this.lb_valuexp.Text = "Xuất phát";
            this.lb_valuexp.Visible = false;
            // 
            // lb_valuephuongtien
            // 
            this.lb_valuephuongtien.AutoSize = true;
            this.lb_valuephuongtien.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_valuephuongtien.Location = new System.Drawing.Point(166, 408);
            this.lb_valuephuongtien.Name = "lb_valuephuongtien";
            this.lb_valuephuongtien.Size = new System.Drawing.Size(94, 20);
            this.lb_valuephuongtien.TabIndex = 5;
            this.lb_valuephuongtien.Text = "Phương tien";
            this.lb_valuephuongtien.Visible = false;
            // 
            // lb_matour
            // 
            this.lb_matour.AutoSize = true;
            this.lb_matour.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lb_matour.Location = new System.Drawing.Point(166, 549);
            this.lb_matour.Name = "lb_matour";
            this.lb_matour.Size = new System.Drawing.Size(63, 20);
            this.lb_matour.TabIndex = 4;
            this.lb_matour.Text = "Mã tour";
            this.lb_matour.Visible = false;
            // 
            // btn_datve
            // 
            this.btn_datve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_datve.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btn_datve.Location = new System.Drawing.Point(462, 625);
            this.btn_datve.Name = "btn_datve";
            this.btn_datve.Size = new System.Drawing.Size(166, 52);
            this.btn_datve.TabIndex = 2;
            this.btn_datve.Text = "Đặt Tour";
            this.btn_datve.UseVisualStyleBackColor = true;
            this.btn_datve.Visible = false;
            this.btn_datve.Click += new System.EventHandler(this.btn_datve_Click);
            // 
            // lb_giatour
            // 
            this.lb_giatour.AutoSize = true;
            this.lb_giatour.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lb_giatour.Location = new System.Drawing.Point(167, 588);
            this.lb_giatour.Name = "lb_giatour";
            this.lb_giatour.Size = new System.Drawing.Size(79, 20);
            this.lb_giatour.TabIndex = 1;
            this.lb_giatour.Text = "giá TOUR";
            this.lb_giatour.Visible = false;
            // 
            // lb_tentour
            // 
            this.lb_tentour.AutoSize = true;
            this.lb_tentour.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tentour.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lb_tentour.Location = new System.Drawing.Point(16, 25);
            this.lb_tentour.Name = "lb_tentour";
            this.lb_tentour.Size = new System.Drawing.Size(164, 33);
            this.lb_tentour.TabIndex = 0;
            this.lb_tentour.Text = "Tên TOUR";
            this.lb_tentour.Visible = false;
            // 
            // btn_tim
            // 
            this.btn_tim.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_tim.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btn_tim.Location = new System.Drawing.Point(166, 76);
            this.btn_tim.Name = "btn_tim";
            this.btn_tim.Size = new System.Drawing.Size(75, 26);
            this.btn_tim.TabIndex = 6;
            this.btn_tim.Text = "Tìm";
            this.btn_tim.UseVisualStyleBackColor = true;
            this.btn_tim.Click += new System.EventHandler(this.btn_tim_Click);
            // 
            // lb_tennv
            // 
            this.lb_tennv.AutoSize = true;
            this.lb_tennv.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tennv.Location = new System.Drawing.Point(469, 94);
            this.lb_tennv.Name = "lb_tennv";
            this.lb_tennv.Size = new System.Drawing.Size(84, 25);
            this.lb_tennv.TabIndex = 7;
            this.lb_tennv.Text = "Tên NV";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.comboBoxTransport);
            this.groupBox1.Controls.Add(this.comboBoxBudget);
            this.groupBox1.Controls.Add(this.btn_all);
            this.groupBox1.Controls.Add(this.comboBoxTourType);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.dgv_thongtintour);
            this.groupBox1.Controls.Add(this.btn_tim);
            this.groupBox1.Controls.Add(this.txt_timtour);
            this.groupBox1.Location = new System.Drawing.Point(12, 122);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(813, 592);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Danh sách TOUR";
            // 
            // comboBoxTransport
            // 
            this.comboBoxTransport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxTransport.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.comboBoxTransport.FormattingEnabled = true;
            this.comboBoxTransport.Items.AddRange(new object[] {
            "Máy Bay",
            "Xe"});
            this.comboBoxTransport.Location = new System.Drawing.Point(616, 76);
            this.comboBoxTransport.Name = "comboBoxTransport";
            this.comboBoxTransport.Size = new System.Drawing.Size(170, 26);
            this.comboBoxTransport.TabIndex = 30;
            this.comboBoxTransport.Text = "Lọc theo phương tiện";
            this.comboBoxTransport.SelectedIndexChanged += new System.EventHandler(this.comboBoxTransport_SelectedIndexChanged);
            // 
            // comboBoxBudget
            // 
            this.comboBoxBudget.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxBudget.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.comboBoxBudget.FormattingEnabled = true;
            this.comboBoxBudget.Items.AddRange(new object[] {
            "Dưới $200",
            "Từ $200 đến $400",
            "Từ $400 đến $800",
            "Trên $800"});
            this.comboBoxBudget.Location = new System.Drawing.Point(446, 76);
            this.comboBoxBudget.Name = "comboBoxBudget";
            this.comboBoxBudget.Size = new System.Drawing.Size(147, 26);
            this.comboBoxBudget.TabIndex = 29;
            this.comboBoxBudget.Text = "Lọc theo ngân sách";
            this.comboBoxBudget.SelectedIndexChanged += new System.EventHandler(this.comboBoxBudget_SelectedIndexChanged);
            // 
            // btn_all
            // 
            this.btn_all.BackColor = System.Drawing.Color.SeaGreen;
            this.btn_all.FlatAppearance.BorderSize = 0;
            this.btn_all.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_all.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_all.ForeColor = System.Drawing.Color.White;
            this.btn_all.Location = new System.Drawing.Point(641, 541);
            this.btn_all.Name = "btn_all";
            this.btn_all.Size = new System.Drawing.Size(145, 32);
            this.btn_all.TabIndex = 28;
            this.btn_all.Text = "Tất cả";
            this.btn_all.UseVisualStyleBackColor = false;
            this.btn_all.Click += new System.EventHandler(this.btn_all_Click);
            // 
            // comboBoxTourType
            // 
            this.comboBoxTourType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxTourType.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.comboBoxTourType.FormattingEnabled = true;
            this.comboBoxTourType.Items.AddRange(new object[] {
            "Cao Cấp",
            "Tiêu Chuẩn",
            "Tiết Kiệm"});
            this.comboBoxTourType.Location = new System.Drawing.Point(294, 76);
            this.comboBoxTourType.Name = "comboBoxTourType";
            this.comboBoxTourType.Size = new System.Drawing.Size(132, 26);
            this.comboBoxTourType.TabIndex = 8;
            this.comboBoxTourType.Text = "Lọc theo loại tour";
            this.comboBoxTourType.SelectedIndexChanged += new System.EventHandler(this.comboBoxTourType_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.Location = new System.Drawing.Point(13, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(161, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "Nhập tên tour cần tìm";
            // 
            // dgv_thongtintour
            // 
            this.dgv_thongtintour.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_thongtintour.BackgroundColor = System.Drawing.Color.White;
            this.dgv_thongtintour.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_thongtintour.Location = new System.Drawing.Point(17, 109);
            this.dgv_thongtintour.Name = "dgv_thongtintour";
            this.dgv_thongtintour.RowHeadersWidth = 51;
            this.dgv_thongtintour.Size = new System.Drawing.Size(769, 418);
            this.dgv_thongtintour.TabIndex = 0;
            this.dgv_thongtintour.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_thongtintour_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(357, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 25);
            this.label1.TabIndex = 6;
            this.label1.Text = "Nhân viên:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.ErrorImage = null;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(29, 23);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 72);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 27;
            this.pictureBox1.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(135, 45);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(121, 37);
            this.label6.TabIndex = 26;
            this.label6.Text = "Đặt Vé";
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "dalat1.jpg");
            this.imageList1.Images.SetKeyName(1, "japan1.jpg");
            this.imageList1.Images.SetKeyName(2, "korea1.jpg");
            this.imageList1.Images.SetKeyName(3, "malaysia1.jpg");
            this.imageList1.Images.SetKeyName(4, "phuquoc1.jpg");
            this.imageList1.Images.SetKeyName(5, "sapa1.jpg");
            this.imageList1.Images.SetKeyName(6, "sp1.jpg");
            this.imageList1.Images.SetKeyName(7, "danang1.jpg");
            // 
            // DatTour
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1455, 741);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.lb_tennv);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DatTour";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Đặt Tour";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.QLTour_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ptb_anhtour)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_thongtintour)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

          #endregion

        private System.Windows.Forms.Label lbType;
          private System.Windows.Forms.Label lbDescription;
          private System.Windows.Forms.Label lbPrice;
          private System.Windows.Forms.Label lbIDTour;
          private System.Windows.Forms.PictureBox ptb_anhtour;
          private System.Windows.Forms.TextBox txt_timtour;
          private System.Windows.Forms.Label lb_tenloaitour;
          private System.Windows.Forms.GroupBox groupBox4;
          private System.Windows.Forms.Label lb_tgketthuc;
          private System.Windows.Forms.Label lb_thoigian;
          private System.Windows.Forms.Label lb_tgbatdau;
          private System.Windows.Forms.Label lb_valueslve;
          private System.Windows.Forms.Label lb_slve;
          private System.Windows.Forms.Label lb_phuongtien;
          private System.Windows.Forms.Label lb_xp;
          private System.Windows.Forms.Label lb_valuexp;
          private System.Windows.Forms.Label lb_valuephuongtien;
          private System.Windows.Forms.Label lb_matour;
          private System.Windows.Forms.Button btn_datve;
          private System.Windows.Forms.Label lb_giatour;
          private System.Windows.Forms.Label lb_tentour;
          private System.Windows.Forms.Button btn_tim;
          private System.Windows.Forms.Label lb_tennv;
          private System.Windows.Forms.GroupBox groupBox1;
          private System.Windows.Forms.DataGridView dgv_thongtintour;
          private System.Windows.Forms.Label label1;
          private System.Windows.Forms.RichTextBox richboxDescription;
          private System.Windows.Forms.Label label2;
          private System.Windows.Forms.PictureBox pictureBox1;
          private System.Windows.Forms.Label label6;
          private System.Windows.Forms.ComboBox comboBoxTourType;
          private System.Windows.Forms.ImageList imageList1;
          private System.Windows.Forms.Button btn_all;
        private System.Windows.Forms.ComboBox comboBoxTransport;
        private System.Windows.Forms.ComboBox comboBoxBudget;
    }
}